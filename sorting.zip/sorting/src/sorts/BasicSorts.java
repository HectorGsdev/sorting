package sorts;

import utilities.SortingUtilities;

/**
 * @author Hector Gonzalez
 * @version V 1.0 04/22/22 1234
 */
public class BasicSorts
{
    /**
     * @param array received the array to be sorted as a parameter
     *              using bubble sort  algorithm
     */
    public void bubbleSort(int[] array)
    {
        // this determines how many "passes over the array
        for (int i = 0; i < array.length; i++)
        {
            //this determines which adjacent elements will bubble
            for (int j = 0; j < array.length - 1 - i; j++)
            {
                // see if adjacent elements are out of order
                if (array[j] > array[j + 1])
                {
                    //swap them
                    SortingUtilities.swap(array, j, j + 1);
                }
            }
        }
    }


    /**
     * * * * * * * * * * SELECTION SORT * * * * * * * * * * * * *
     *
     * @param array received the array to be sorted as a parameter
     *              using selection sort  algorithm
     */
    public void selectionSort(int[] array)
    {
        for (int i = 0; i < array.length; i++)
        {
            // find the index of the smallest element in the array starting at position i
            int smallIndex = (findIndexSmaller(array, i));
            // swap the smallest element in the array with the element in position array[i]
            SortingUtilities.swap(array, i, smallIndex);
        }
    }

    /**
     * helper function to find the smallest number in the array and return the index
     *
     * @param array            The array where this function is going to look for the index of the smallest number
     * @param startingPosition each iteration the function will start the search after the
     * @return the index of the smallest number in the array
     */
    public int findIndexSmaller(int[] array, int startingPosition)
    {
        int tempSmall = Integer.MAX_VALUE;
        int resultIndex = 0;
        for (int j = startingPosition; j < array.length; j++)
        {
            if (array[j] < tempSmall)
            {
                tempSmall = array[j];
                resultIndex = j;
            }
        }
        return resultIndex;
    }


    //TODO INSERTION SORT

    /**
     * @param array received the array to be sorted as a parameter
     *              using insertion sort  algorithm
     */
    public void insertionSort(int[] array)
    {
        int positionToInsert =0;
        for (int i = 0; i < array.length - 1; i++)
        {
            for (int j = i + 1; j > i; j = j - 1)
            {
                if (array[j] < array[i])
                {
                   positionToInsert =  findPosition(array, j);
                   insertElement(array, positionToInsert);
                }

            }
            System.out.println();
        }
    }


    /**
     * @param array       Array to be sorted
     * @param insertIndex index of the number to be inserted
     * @return the position where the element should go
     */
    public int findPosition(int[] array, int insertIndex)
    {

        // find position
        for (int i = 0; i < array.length; i++)
        {
            if (array[insertIndex] < array[i])
            {
                return i;
            }
        }
      return -1;
    }



    public int insertElement(int[] array, int position )
    {
        int[] arrayTempo = new int[array.length];
        boolean found = false;

        for (int i = 0; i < array.length; i++)
        {
           if (i == position)
           {
               found = true;
               arrayTempo [i] = array[i]
           }


        }

    }






}








